#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#
library(DT)
library(shiny)
library(shinydashboard)
library(echarts4r)
library(tidyverse)
library(glue)
library(leaflet)
library(sf)
library(countrycode)
library(geojsonio)
library(RColorBrewer)
library(htmltools)
library(highcharter)
library(GGally)
library(glue)
library(gganimate)
library(babynames)
library(hrbrthemes)
library(gapminder)
library(ggridges)
library(lubridate)
library(rio)
library(scales)
library(stringr)
library(leaflet)
library(plotly)

covid <- read_csv("owid-covid-data.csv")
covid$year_date <- year(covid$date)
covid$month_date <- month(covid$date, label = T, abbr = F)
covid <- covid %>% rename('Timeline' = 'date', 'Dailycases' = 'new_cases', 'Dailydeaths' = 'new_deaths', 'Country' = 'location')
covid[is.na(covid$Dailycases), "Dailycases"] <- 0
covid[is.na(covid$total_cases), "total_cases"] <- 0
covid[is.na(covid$Dailydeaths), "Dailydeaths"] <- 0
covid[is.na(covid$total_deaths), "total_deaths"] <- 0
covid[is.na(covid$total_cases_per_million), "total_cases_per_million"] <- 0
covid[is.na(covid$new_cases_per_million), "new_cases_per_million"] <- 0
covid[is.na(covid$total_vaccinations), "total_vaccinations"] <- 0
covid[is.na(covid$population), "population"] <- 0
covid[is.na(covid$positive_rate), "positive_rate"] <- 0
# Define UI for application that draws a histogram
ui <- 
  dashboardPage(skin = "green",
                
                # Fungsi dashboardHeader() adalah bagian untuk membuat header
                dashboardHeader(title = "Corona Virus Pandemic"),
                
                # Fungsi dashboardSidebar() adalah bagian untuk membuat sidebar
                dashboardSidebar(
                  sidebarMenu(
                    menuItem(
                      text = "Data Raw",
                      tabName = "page1",
                      icon = icon("table")),
                    menuItem(
                      text = "Line",
                      tabName = "page2",
                      icon = icon("line")),
                    menuItem(
                      text = "Pie",
                      tabName = "page3",
                      icon = icon("people-pulling")),
                    menuItem(
                      text = "Map",
                      tabName = "page4",
                      icon = icon("user"))
                  )
                ),
                dashboardBody(
                  tags$head(tags$style(HTML(".small-box {height : 450px}"))),
                  tabItems(
                  tabItem(
                    tabName = "page1",
                    box(width = 12,dataTableOutput(outputId = "dt1"))
                  ),
                  
                tabItem(tabName = "page2", fluidRow(
                        fluidRow(
                        box(plotlyOutput(outputId = "Plot1" ),width = 8, height = 450),
                        valueBox("Per 27 October 2022", "Daily Cases = 3029",
                                 icon = icon("calendar"),
                                 color = "maroon",
                                 width = 4),
                        valueBox("Per 27 October 2022", "Daily Deaths = 23",
                                 icon = icon("calendar"),
                                 color = "maroon",
                                 width = 4),
                        box(plotlyOutput(outputId = "Plot4" ),width = 8, height = 450),
                        box(echarts4rOutput(outputId = "Plot2" ),width = 8, height = 450),
                        valueBox("Per 27 October 2022", "Cumulative Cases = 6.481.749",
                                 icon = icon("calendar"),
                                 color = "maroon",
                                 width = 4),
                        
                        valueBox("Per 27 October 2022", "Confirmed Death = 158.475",
                                 icon = icon("calendar"),
                                 color = "maroon",
                                 width = 4),
                        box(echarts4rOutput(outputId = "Plot5" ),width = 8, height = 450),
                        box(echarts4rOutput(outputId = "Plot7" ),width = 8, height = 450),
                        valueBox("Per 27 October 2022", "Confirmed Death = 158.475	Cumulative Cases = 6.481.749",
                                 icon = icon("calendar"),
                                 color = "maroon",
                                 width = 4)),
                        # box(echarts4rOutput(outputId = "Plot3" )),
                      
                )  
                 ),
                
                tabItem(tabName = "page3",fluidRow(
                  valueBox("629.437.595	", "Confirmed Covid Cumulative Case of World per 27 October 2022",
                           icon = icon("calendar"),
                           color = "maroon",
                           width = 9),
                  box(radioButtons(inputId = "radio", label = "change theme?",  choices = c("yes","no"), selected = "no"
                              ),width = 3, height = 450),
                        box(echarts4rOutput(outputId = "Plot8"),width = 12),
                     
                   
                        )),
                        
             
                tabItem(tabName = "page4",
                        fluidRow(
                        
                       box(sliderInput("date",
                                    "Dates:",
                                    min = as.Date("2020-03-07","%Y-%m-%d"),
                                    max = as.Date("2022-10-27","%Y-%m-%d"),
                                    value=as.Date("2022-10-27"),timeFormat="%Y-%m-%d"),width = 12),
                        box(echarts4rOutput(outputId = "Plot3",height = 400),width = 8, height = 450),
                       valueBox("456.213", "Confirmed Covid Daily Case of World per 27 October 2022",
                                icon = icon("calendar"),
                                color = "maroon",
                                width = 4),
                       valueBoxOutput(outputId = "box1"),
                        box(echarts4rOutput(outputId = "Plot9",height = 400),width = 8, height = 450),
                    
                        )
                  )
                )
                )
  )


# Define server logic required to draw a histogram
server <- function(input, output, session) {
  

    output$Plot1 <- renderPlotly({
      idn_dailycase <- covid %>%
        select(Country, Timeline, Dailycases) %>%
        filter(Country %in% "Indonesia")%>%
        mutate(label = glue("Timeline: {Timeline}
                      Dailycases: {Dailycases}"))
      idn_dailyplot <- 
        ggplot(data = idn_dailycase, mapping = aes(x = Timeline, 
                                                   y = Dailycases, 
                                                   text = label))+
        geom_line(group = 10, color = "seagreen4") +
        scale_x_date(date_breaks = "8 weeks", date_labels = "%W") +
        scale_y_continuous(labels = scales::comma) +
        labs(title = "Daily Number of Confirmed Cases In Indonesia",
             x = "Timeline per 8 Weeks",
             y = "Daily Cases Confirmed") +
        theme_minimal()
      
      ggplotly(p =idn_dailyplot, tooltip = "text")
      
      
    })
    
      output$Plot2 <- renderEcharts4r({idn_totalcases <- covid %>%
      select(Country, Timeline, total_cases) %>%
      filter(Country %in% "Indonesia")%>%
      mutate(label = glue("Timeline: {Timeline}
                      Total cases: {total_cases}"))
    
    idn_totalcases %>%  
      e_charts(Timeline) %>%  
      e_line(total_cases) %>% 
      e_color(color = "green" ) %>% 
      e_datazoom() %>% 
      e_title("cumulative Number of 
          Confirmed Cases in Indonesia") %>%
      e_tooltip(trigger = "axis")
      
    })
      
       output$Plot3 <- renderEcharts4r({
         world_dailycase <- covid %>% filter(Timeline == input$date)
         
         # world_dailycase %>% 
         # select(Country, Timeline, Dailycases) %>%
         # mutate(label = glue("Timeline: {Timeline}
         #              Dailycases: {Dailycases}"))
       world_dailycase %>% 
         e_charts(Country) %>%
         e_map(Dailycases) %>%
         e_visual_map(Dailycases) %>%
         e_tooltip()
  
})
       output$Plot9 <- renderEcharts4r({
         world_dailycase2 <- covid %>% filter(Timeline == input$date)
         
         # world_dailycase %>% 
         # select(Country, Timeline, Dailycases) %>%
         # mutate(label = glue("Timeline: {Timeline}
         #              Dailycases: {total_case}"))
         world_dailycase2 %>% 
           e_charts(Country) %>%
           e_map(total_cases) %>%
           e_visual_map(total_cases) %>%
           e_tooltip()
         
       })     
       output$Plot4 <- renderPlotly({idn_dailydeath <- 
         covid %>% 
         dplyr::select(Country, Timeline, Dailydeaths) %>%
         filter(Country %in% "Indonesia")%>%
         mutate(label = glue("Timeline: {Timeline}
                      Dailydeaths: {Dailydeaths}"))
       idn_dailydeathplot <- 
         ggplot(data = idn_dailydeath, mapping = aes(x = Timeline, 
                                                     y = Dailydeaths, 
                                                     text = label))+
         geom_line(group = 10, color = "red3") +
         scale_x_date(date_breaks = "8 weeks", date_labels = "%W") +
         scale_y_continuous(labels = scales::comma) +
         labs(title = "Daily Number of Confirmed Deaths In Indonesia",
              x = "Timeline per 8 Weeks",
              y = "Daily Deaths Confirmed") +
         theme_minimal()
       
       ggplotly(p =idn_dailydeathplot, tooltip = "text")
         
       })
       output$Plot5 <- renderEcharts4r({idn_cumdeaths <- 
         covid %>% 
         dplyr::select(Country, Timeline, total_deaths) %>%
         filter(Country %in% "Indonesia")%>%
         mutate(label = glue("Timeline: {Timeline}
                      Cumulative Deaths: {total_deaths}"))
       idn_cumdeaths %>%  
         e_charts(Timeline) %>%  
         e_line(total_deaths) %>% 
         e_datazoom() %>%
         e_color(color = "red") %>% 
         e_title("Cumulative Number of 
          Confirmed Deaths in Indonesia") %>%
         e_tooltip(trigger = "axis")
       })
       output$Plot6 <- renderEcharts4r({world_totalcase <- 
         covid %>% 
         select(Country, Timeline, total_cases) %>%
         mutate(label = glue("Timeline: {Timeline}
                      Total Cases: {total_cases}"))
       world_totalcase %>% filter(Timeline == "2020-03-07") %>%
         e_charts(Country) %>%
         e_map(total_cases) %>%
         e_visual_map(total_cases) %>%
         e_tooltip()
       })
       output$Plot7 <- renderEcharts4r({
         idn_mortality_risk <- 
           covid %>% 
           dplyr::select(Country, Timeline, total_cases, total_deaths) %>%
           filter(Country %in% "Indonesia")
         
         idn_mortality_risk %>%  
           e_charts(Timeline) %>%  
           e_line(total_cases, itemStyle = list(color = "green")) %>%  
           e_line(total_deaths, itemStyle = list(color = "red")) %>% 
           e_datazoom() %>% 
           e_title("Mortality Risk of 
          Covid 19 in Indonesia") %>%
           e_tooltip(trigger = "axis")
       })
       output$Plot8 <- renderEcharts4r({
         highest_total_death <-
           covid %>% 
           select(Timeline, Country, total_deaths) %>%
           filter(Country %in% c("Africa", "Asia", "Europe", "North America", "Oceania","South America " ), Timeline == as.character("2022-10-27")) %>%
           group_by(Country, Timeline, total_deaths) %>%
           arrange(-total_deaths)
         highest_total_death %>% group_by(Country) %>%  summarise(sum = sum(total_deaths)) %>% 
           e_charts(Country) %>%  
           e_pie(sum, radius = c('40%', '70%'),
                 itemStyle = list(borderRadius= 10, borderColor = "#fff", borderWidth = 2),
                 emphasis = list(show = T, fontSize = "40", label = list(show = T))) %>%  
           e_title("Total Death by Contingent", position = "bottom")  %>% 
           e_labels(show = FALSE,
                    position = "center",
                    fontSize = 14,
                    fontWeigth = "bold",
                    formatter = "{b} \n Percentage of Death by Contingen : {d}% \n Total Death : {c}") %>%
           e_legend(type = c("scroll"), right = 0,orient = "vertical") %>% 
           e_theme(ifelse(input$radio == "yes", "chalk", "westeros"))
       })
       
       output$dt1 <- renderDataTable (covid,
         options = list(pageLength = 50, scrollx=T)
       )
       
       output$date1 <- renderText({
         paste(input$date)
       })
       
       output$box1 <- renderValueBox({
         valueBox("629.437.595	", "Confirmed Covid Cumulative Case of World per 27 October 2022",
                  icon = icon("calendar"),
                  color = "maroon",
                  width = 4)
       })
       
       output$btn <- renderText({
         paste0(input$radio)
       })

}

# Run the application 




shinyApp(ui = ui, server = server)
